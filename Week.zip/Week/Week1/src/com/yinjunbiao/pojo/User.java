package com.yinjunbiao.pojo;

/**
 * 实体类
 */
public class User {
    private Integer id;
    private String name;
    private String studentId;
    private String password;
    private Integer academy;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", studentId='" + studentId + '\'' +
                ", password='" + password + '\'' +
                ", academy=" + academy +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getAcademy() {
        return academy;
    }

    public void setAcademy(Integer academy) {
        this.academy = academy;
    }

    public User() {
    }

    public User(Integer id, String name, String studentId, String password, Integer academy) {
        this.id = id;
        this.name = name;
        this.studentId = studentId;
        this.password = password;
        this.academy = academy;
    }
}
