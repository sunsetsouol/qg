package com.yinjunbiao.Test;


import com.yinjunbiao.ConnectionPool.Impl.MyConnectionPoolImpl;

import java.sql.Connection;

public class DBThread implements Runnable{
    MyConnectionPoolImpl pool = null;
    Connection connection = null;

    public DBThread(MyConnectionPoolImpl pool) {
        this.pool = pool;
    }

    @Override
    public void run() {
        for (int i = 0; i < 15; i++) {
            connection = pool.getConnection();
            System.out.println(connection);
            System.out.println(Thread.currentThread().getName()+"connection---"+connection+"成功");
        }
    }
}
