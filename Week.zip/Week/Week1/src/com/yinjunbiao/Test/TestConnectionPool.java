package com.yinjunbiao.Test;


import com.yinjunbiao.ConnectionPool.Impl.MyConnectionPoolImpl;
import org.junit.Test;

public class TestConnectionPool {
    @Test
    public void TestConnection(){

        MyConnectionPoolImpl pool = new MyConnectionPoolImpl("superPool.properties");

        DBThread dbThread1 = new DBThread(pool);
        DBThread dbThread2 = new DBThread(pool);
        DBThread dbThread3 = new DBThread(pool);

        Thread thread1 = new Thread(dbThread1,"线程1");
        Thread thread2 = new Thread(dbThread2,"线程2");
        Thread thread3 = new Thread(dbThread3,"线程3");

        thread1.start();
        thread2.start();
        thread3.start();

        try {
            thread1.join();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
