package com.yinjunbiao.Test;

import com.yinjunbiao.pojo.User;
import com.yinjunbiao.util.CrudUtil;
import org.junit.Test;

public class TestCRUD {

    @Test
    public void testCRUD(){
        User user = CrudUtil.selectUserById(1);
        System.out.println(user);
        String sql = "update user set number = ? where id = ?";
        Object[]msg = {"111",29};
        CrudUtil.updateUser(sql,msg);

    }

}
