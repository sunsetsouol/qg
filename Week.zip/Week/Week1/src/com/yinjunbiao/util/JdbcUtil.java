package com.yinjunbiao.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtil {
    private static String url;
    private static String username;
    private static String password;
    private static String driverName;
    static {

        try {
            Properties properties = new Properties();
            InputStream inputStream = ClassLoader.getSystemResourceAsStream("jdbc.properties");
            properties.load(inputStream);
            url = properties.getProperty("url");
            username = properties.getProperty("userName");
            driverName = properties.getProperty("driverName");
            password = properties.getProperty("password");
            Class.forName(driverName);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static Connection getConnection(){
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url,username,password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return connection;
    }
}
