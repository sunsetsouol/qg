package com.yinjunbiao.util;

import com.yinjunbiao.pojo.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CrudUtil {

    private CrudUtil() {
    }

    public static User selectUserById(int id) {
        Connection connection = JdbcUtil.getConnection();
        String sql = "select * from user where id = ?";

        User user = null;
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,id);

            ResultSet resultSet = preparedStatement.executeQuery();
            user = new User();
            while (resultSet.next()){
                id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String studentId = resultSet.getString(3);
                String password = resultSet.getString(4);
                int academy = resultSet.getInt(5);
                user.setAcademy(academy);
                user.setPassword(password);
                user.setStudentId(studentId);
                user.setName(name);
                user.setId(id);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        return user;
    }

    public static void insertUser(User user)  {
        String sql = "insert into user values(null,?,?,?,?)";
        Connection connection = JdbcUtil.getConnection();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            connection.setAutoCommit(false);

            preparedStatement.setString(1,user.getName());
            preparedStatement.setString(2,user.getStudentId());
            preparedStatement.setString(3,user.getPassword());
            preparedStatement.setInt(4,user.getAcademy());

            int i = preparedStatement.executeUpdate();
            System.out.println(i);
            connection.commit();
            preparedStatement.close();
            connection.close();
        } catch (Exception throwables) {
            throwables.printStackTrace();
            try {
                System.out.println("error");
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public static void deleteUser(int id){
        String sql = "delete from user where id = ?";
        Connection connection = JdbcUtil.getConnection();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            connection.setAutoCommit(false);

            preparedStatement.setInt(1,id);

            int i = preparedStatement.executeUpdate();
            System.out.println(i);
            connection.commit();
            preparedStatement.close();
            connection.close();
        } catch (Exception throwables) {
            throwables.printStackTrace();
            try {
                System.out.println("error");
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void updateUser(String sql,Object[]msg){
        Connection connection = JdbcUtil.getConnection();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            connection.setAutoCommit(false);

            if (msg != null && msg.length != 0){
                for (int i = 0; i < msg.length; i++) {
                    if (msg[i] instanceof Integer){
                        preparedStatement.setInt(i+1, (Integer) msg[i]);
                    }
                    if (msg[i] instanceof String){
                        preparedStatement.setString(i+1, (String) msg[i]);
                    }
                }
            }
            preparedStatement.executeUpdate();
            connection.commit();
            preparedStatement.close();
            connection.close();
        } catch (Exception throwables) {
            throwables.printStackTrace();
            try {
                System.out.println("error");
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


}
