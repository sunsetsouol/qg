package com.yinjunbiao.ConnectionPool.Impl;


/**
 * 数据库连接池
 */

import com.yinjunbiao.ConnectionPool.MyConnectionPool;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Properties;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 手写连接池
 * @author yinjunbiao
 * @version 1.0
 */
public class MyConnectionPoolImpl implements MyConnectionPool {
    /**
     * 阻塞队列
     * 活跃连接
     * 空闲连接
     * 当前线程数
     */
    static LinkedBlockingQueue<Object> queue = null;

    final LinkedList<Connection> pool = new LinkedList<>();


    private static String driverName ;

    private static String url ;
    private static String userName ;
    private static String password ;

    private String poolName ;

    private int minConnections;

    private int maxConnections;

    private int initConnections ;

    private long connTimeOut ;

    private int expandConnections;
    private AtomicInteger count = null;

    //读取信息，注册驱动
    static {

        try {
            Properties properties = new Properties();
            InputStream inputStream = ClassLoader.getSystemClassLoader().getResourceAsStream("jdbc.properties");
            System.out.println(inputStream);
            properties.load(inputStream);
            url = properties.getProperty("url");
            userName = properties.getProperty("userName");
            password = properties.getProperty("password");
            driverName = properties.getProperty("driverName");

            Class.forName(driverName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 构造函数 根据路径文件读取信息
     * @param path 资源路径
     */
    public MyConnectionPoolImpl(String path) {
        try {
            Properties properties = new Properties();
            InputStream inputStream = ClassLoader.getSystemClassLoader().getResourceAsStream(path);
            properties.load(inputStream);
            poolName = properties.getProperty("poolName");
            minConnections = Integer.parseInt(properties.getProperty("minConnections"));
            maxConnections = Integer.parseInt(properties.getProperty("maxConnections"));
            initConnections =Integer.parseInt(properties.getProperty("initConnections"));
            connTimeOut =Integer.parseInt(properties.getProperty("connTimeOut"));
            expandConnections = Integer.parseInt(properties.getProperty("expandConnections"));
            queue = new LinkedBlockingQueue<>(initConnections);
            count = new AtomicInteger(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
        init(initConnections);
    }

    /**
     * 创建连接,添加到连接池中
     */
    private void init(int num) {

        for (int i = 0; i < num; i++) {
            Connection connection = newConnection();
            if (connection != null) {
                pool.add(connection);
            }
        }

    }

    /**
     * 创建新的连接
     * @return 返回新创建的连接
     */
    private Connection newConnection() {

        try {
            Connection connection = DriverManager.getConnection(url,userName,password);
            count.incrementAndGet();
            return connection;
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }

        return null;
    }


    @Override
    public Connection getConnection() {
        Connection connection = null;
        //如果当前线程数没有达到上限，如果空闲线程池中有空闲连接，则直接获取，如果没有则新建连接，如果达到上限，则加入阻塞队列等待
        if (pool.size()<minConnections && count.get()<maxConnections){
            synchronized (MyConnectionPoolImpl.class){
                if (pool.size()<minConnections && count.get()<maxConnections){
                    init(expandConnections);
                }
            }
        }
        if (pool.size()>0){
            synchronized (pool){
                if (pool.size()>0){
                    connection = pool.removeLast();
                    queue.offer(new Object());
                }
            }
        }
        if (connection == null){
            try {
                //如果线程线程数量达到上限，则加入阻塞队列
                queue.offer(new Object(),connTimeOut, TimeUnit.MILLISECONDS);
                connection = getConnection();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    private boolean isAvaliable(Connection connection) {
        try {
            if (connection != null && !connection.isClosed()){
                return true;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }

    /**
     * 返回连接
     * @param connection 连接对象
     */
    @Override
    public synchronized void releaseConnection(Connection connection) {
        //如果conncection不为空且未关闭，如果空闲连接队列没满则直接放进空闲队列，如果满了则关闭连接
        try {
            if (connection != null){
                if (isAvaliable(connection)){
                    pool.addFirst(connection);
                }else {
                    connection.close();
                    count.decrementAndGet();
                }
                queue.poll();
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
